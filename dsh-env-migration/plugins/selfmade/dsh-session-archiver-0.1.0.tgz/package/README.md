# dsh-session-archiver

DSH host 侧插件：**自动增量归档**本机会话到已有的 SQLite 知识库
`~/.dsh-analysis/sessions-archive/sessions-archive.db`，并为「网页版 GPT 提炼」环节
准备素材包队列。**不重建解码器、不改现有 schema、不碰任何历史脚本**。

---

## 1. 它做什么

| 能力 | 说明 |
|---|---|
| 自动增量归档 | DSH 启动即在后台工作；新会话、新事件自动入库 |
| 幂等 | 按 `source_path` 唯一约束判定，已归档 artifact 绝不重复；同一文件二次扫描 0 写入 |
| 只读新增部分 | 记录「已消费字节游标 + 尾部 hash」，续传时只读新增字节、只解新增 zstd 帧 |
| 提炼队列 | 新入库事件进 `archiver_queue`（`status='pending'`），导出素材包后标记 `packed` |
| 素材包导出 | 复刻 `build-packs-v2.mjs` 的摘要格式，写入 `packs-auto/`，可直接丢给网页版 GPT |
| 状态可观测 | `/archive-status` 给出已归档计数 / 待提炼数量 / 最近错误 |
| 永不拖垮宿主 | 全部后台异步 + 节流 + 单飞；任何异常都吞掉并落日志，宿主照常启动 |

---

## 2. 触发方式选型：文件监听（fs.watch）而非订阅 DSH 事件

侦查了真实接口（`dsh-session` / `dsh-agent` / `dsh-session-persistence` 的 `.d.ts`）之后确认两边都能拿到信息：

- **可订阅的事件面存在**：`session/created`、`session/disposed`、`session/event`（注释原文是
  "Post-commit, fire-and-forget append feed"，监听器抛错不会影响 append）、`agent/created` 等。
- **`ctx.sessionPersistence.open(id,'read').read(offset,length)` 也能按 offset 读逻辑事件。**

**仍然选择 (b) 文件监听**，理由：

1. **归档的主键是「文件（artifact）」而不是「会话」。** 库里 149 个 artifact 对应磁盘文件，
   同一 session id 可能同时存在 `session.jsonl.zstd`(v0) 与 `session.v3.jsonl.zstd`(v3)。
   而 `sessionPersistence` 只在 **session 维度**给事件流，看不到 `source_path` / `source_sha256` /
   `frame_count` 这些 artifact 级事实——用它归档会丢掉物理维度，正是当年「v3 覆盖 v0」那个坑。
2. **增量游标天然是字节。** zstd 帧边界就是 append 批次边界，游标 = 字节偏移，
   和 `artifacts.source_bytes` 同一坐标系；事件面给的是逻辑事件，还需额外对账。
3. **解耦于内部 API。** 事件/持久化接口属于宿主内部契约，格式或签名演进时插件会连带崩；
   磁盘布局 + zstd 帧是稳定事实（149 文件 0 解码失败已验证）。
4. **不占热路径。** 监听文件是纯旁路，不需要订阅 append feed、不会给会话写入增加任何开销。

代价与对策：文件监听看不到「会话结束」这类语义事件，也无法感知磁盘外的事件源 ——
因此用 **周期性对账扫描（默认 120s）** 兜底：即使 watch 丢事件（Windows 上 `fs.watch`
在极端情况下会丢），下一个扫描周期也会发现并补齐。

---

## 3. 增量算法（为什么不会全量重解）

每个 artifact 在插件自有表 `archiver_state` 里保存一个游标：

```
written_bytes  已消费到的文件字节偏移（= 已入库所有帧的末尾）
tail_sha256    该偏移前 64KiB 的 hash（检测「同长度原地改写」）
sha256/sha256_bytes   已知的全文件 hash 及其覆盖长度（尺寸 ≤32MiB 时每次全量刷新）
msg_ord        messages 派生层已处理到的事件 ord
```

一次 `syncFile` 的判定顺序：

1. `artifacts.source_bytes === stat.size` → **UNCHANGED**，不读文件、不写库（历史上 148 个静态
   文件走的就是这条路径，0 开销）。
2. 有游标且 `written_bytes === stat.size` → UNCHANGED。
3. 文件缩小（截断/原地替换）→ 重读该 artifact（先删本 artifact 的 events/messages，幂等重建）。
4. 文件变大 → 校验 `tail_sha256`：一致则从 `written_bytes` 只读新增字节；
   **不一致则整文件重读**（安全兜底）。
5. 无游标（历史脚本归档的 artifact）→ **BOOTSTRAP**：用库里已有的 `frame_count`
   做**结构化帧定位**，跳过已归档帧、只解新增帧；仅在「首帧 header 与 `header_json` 完全相等
   且帧数 ≥ 已归档帧数」时采用，否则退回全量重读。

> 实测：`session-810c86c8` 从 656183 字节涨到 1153253 字节，bootstrap 跳过 195 帧、
> 只解 67 帧，`event_count` 358 → 511，**没有全量重解**。

zstd 分帧用结构化扫描器（`lib/zstd.js`，自 `@huanlin/dsh-plugin-yet-another-subagent`
的官方实现移植），它遍历真实 frame/block 头而不是简单搜魔数：并发写入造成的
torn tail 会被**跳过**而不是误解析，返回的帧 end 偏移即精确游标。
（`zlib.zstdDecompressSync` 只解第一帧，所以必须逐帧切片解压。）

---

## 4. 安装

插件市场 / 官方路径（推荐，tarball 或 registry 安装，peer 依赖可正常解析）：

```powershell
npm pack                                   # 生成 dsh-session-archiver-0.1.0.tgz
dsh plugin --profile web-3 add <tarball 路径>
```

> **为什么用 tarball 而不是 `link:<目录>`**：pnpm 的 `link:` 会在 `node_modules` 里建 junction，
> Node 默认按 **realpath** 解析模块，于是从插件真实目录向上找 `node_modules` ——
> 找不到 profile 里的 `@deepseek-ai/schemastery`，settings 集成会静默降级
> （插件仍可用，只是没有 settings 命名空间）。tarball 安装是真实副本，peer 正常解析。
> 另外 `dsh plugin <args>` 的包装层会按空白切分参数，**路径里不能有空格**。
>
> **重新安装（改了代码后刷新）**：`dsh plugin add <同一个 tarball 路径>` 会被 pnpm 视为
> 「spec 未变」而跳过（`added 0`，装的还是旧副本）。必须先去依赖再装：
> `pnpm -C <profile> remove dsh-session-archiver` → 删掉 `node_modules/dsh-session-archiver`
> → `dsh plugin --profile web-3 add <tarball>`，然后用文件 hash 确认已更新。

装完重启 DSH。`package.json` 的 `dsh.bundle.patch` 指向 `cordis.patch.yml`，
dsh 据此把它作为 profile composition 的一层挂载（与 `dsh plugin --profile web-3 add` 同一条路径）。

依赖：仅 Node 内置模块（`node:fs` / `node:path` / `node:crypto` / `node:zlib` / `node:sqlite`）。
`schemastery` / `dsh-settings` / `dsh-commands` 都是 **optional peer**，通过动态 import +
`ctx.inject` 概率性使用：缺失或版本漂移只会让对应能力降级，**不会让宿主启动失败**。

---

## 5. 配置

优先级：**环境变量 > settings 用户层 > composition config（cordis.patch.yml 的 config）> 默认值**。

| 项 | 环境变量 | settings 键 | 默认 |
|---|---|---|---|
| 开关 | `DSH_ARCHIVER_ENABLED` | `enabled` | `true` |
| 归档库 | `DSH_ARCHIVER_DB` | `dbPath` | `~/.dsh-analysis/sessions-archive/sessions-archive.db` |
| 会话根 | `DSH_ARCHIVER_SESSIONS_ROOT` | `sessionsRoot` | `~/.dsh/sessions` |
| 素材包目录 | `DSH_ARCHIVER_PACKS_DIR` | `packsDir` | `~/.dsh-analysis/sessions-archive/packs-auto` |
| 扫描周期 | `DSH_ARCHIVER_SWEEP_MS` | `sweepIntervalMs` | `120000` |
| 触发防抖 | `DSH_ARCHIVER_DEBOUNCE_MS` | `debounceMs` | `3000` |

settings 命名空间为 `session-archiver`（schemastery schema 注册，支持 `watch` 热更新）。

命令：

| 命令 | 作用 |
|---|---|
| `/archive-status` | 已归档 artifacts/sessions/events/messages、待提炼区间数、最近 5 条错误、路径与开关 |
| `/archive-sweep` | 立即执行一次增量扫描（不等节流） |
| `/archive-packs [all]` | 导出素材包（默认只导出待提炼会话；`all` 导出全部会话） |

---

## 6. 提炼闭环（与现有管线兼容）

```
新事件入库 → archiver_queue(pending) → /archive-packs → packs-auto/pack-<时间戳>-NN.md
   → 网页版 GPT（沿用 PROMPT.md 的约定）→ extracted/*.json
   → parse-extracted.mjs（零改动）→ knowledge 表 → export-knowledge.mjs → knowledge/*.md
```

- 包正文格式与 `build-packs-v2.mjs` **逐字一致**（`### SESSION <id>` 头保留，GPT 才能引用
  `evidence_session`；同一套 INJECT 过滤正则、MARK/ERR 片段预算、每会话 ≤6500 字符、每包 ≤100K 字符）。
- 包写入 `packs-auto/`（与 `packs/` **平级**），文件名带时间戳：`packs/` 里 `build-packs-v2.mjs`
  会 `rmSync` 掉所有条目（且对子目录会 EISDIR 抛错），而 `pack-NN.md` 这种名字若复用会让
  `knowledge.pack` 归因撞车。时间戳命名两者都避免。
- 插件**只读**现有表，只新增自有表 `archiver_state` / `archiver_queue` / `archiver_errors`。

---

## 7. 自有表（additive，不动现有 schema）

```sql
archiver_state(artifact_id PK, written_bytes, tail_sha256, tail_window,
               sha256, sha256_bytes, msg_ord, updated_at)
archiver_queue(id PK AUTOINCREMENT, artifact_id, session_id, first_ord, last_ord,
               events, status, pack_file, created_at, updated_at)
archiver_errors(id PK AUTOINCREMENT, at, scope, message)
```

---

## 8. 验证与工具

| 工具 | 作用 |
|---|---|
| `node tools/smoke-test.mjs` | 合成夹具自检 45 项：多帧、v0+v3 并存、幂等、增量、bootstrap、坏路径降级、素材包导出 |
| `node tools/dry-run.mjs` | **只读**预演真实库：逐文件判定 UNCHANGED/NEW/BOOTSTRAP/FULL，预测新增事件数，并落基线快照 |
| `node tools/run-archiver.mjs [--watch=60] [--packs]` | 对真实库实跑：打印 BEFORE/AFTER 计数、幂等复跑、可选监听窗口 |
| `node tools/probe-frames.mjs` | 结构化帧扫描 vs 魔数扫描对账（真实文件上帧数与逐帧解压成功率） |
| `node tools/verify-plugin-load.mjs <模块路径>` | 用假 cordis ctx 加载入口：校验 apply 不抛错、命令与 settings 注册、命令返回契约 |
| `node tools/evidence-report.mjs` | 汇总验收证据到 `evidence/acceptance.md`（前后计数、逐 artifact 增量、新事件直证） |
| `node tools/verify-derived.mjs` | 逐字段对账基线快照，证明派生表零破坏（身份字段 0 改动） |
| `node tools/check-utf8.mjs <文件>` | 用 Node 判断文件编码（控制台乱码 ≠ 文件损坏，看 U+FFFD 与码点） |

已知边界：文件**被原地改写成长度相同的另一份文件**且尾部 64KiB 恰好未变，插件会判为
UNCHANGED（概率极低；会话文件是 append-only 语义，不适用该场景）。
多个宿主进程同时启用本插件也是安全的：事件写入是 `INSERT OR REPLACE`（主键 `(artifact_id, ord)`）
且游标在 `BEGIN IMMEDIATE` 事务内前进，最坏情况是提炼队列出现重复区间（事件层不会重复）。
